/*
    Código correspondiente al ejercicio 6 del TP1.
    Grupo 7 (FISHER, MARTINEZ TANOIRA, SBRUZZI, OMS)
    Consigna:
        Defina una variable porta suponiendo que representa el puerto A del HC11 y asígnele un valor. 
        Se pide crear un programa que realice lo siguiente:
            a. Imprima un 1 si los bits 6 y 1 del puerto están en 1 y/o si los bits 2 y 5 del puerto están en 0;
            b. En caso contrario imprima 0.
            En todos los casos definir máscaras usando #define.
*/

#include <stdio.h>

#define MASK1 0x42 /* 0100 0010, bits que deben estar en 1 */
#define MASK2 0x24 /* 0010 0100, bits que deben estar en 0 */

int main(){ 
        int porta = 0xDB; // Se ingresa un número de testing

        /* El número a printear resulta de la condición:
            La operación AND lógica de porta y la máscara 1 es igual a la máscara (ambos en 1)
            o
            la operación AND lógica de porta invertido bit a bit y la máscara 2  es igual a la máscara
            (ambos en 0, al invertirse, ambos deben estar en 1 para cumplir)
        */
        printf("%d\n", ((MASK1 & porta) == MASK1) || ((MASK2 & ~porta) == MASK2));
        return 0;
}