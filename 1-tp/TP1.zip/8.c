/*
    Código correspondiente al ejercicio 8 del TP1.
    Grupo 7 (FISHER, MARTINEZ TANOIRA, SBRUZZI, OMS)
    Consigna:  
        Escribir un programa que dada una variable tipo double calcule 
        (es decir, genere una nueva variable con el valor) e imprima:
            a. el entero superior (función techo),
            b. el entero inferior (función piso),
            c. el número redondeado a un entero,
            d. la parte entera del número (función truncado),
            e. el número redondeado con 2 decimales.
*/

#include <stdio.h>

int main(void){ 
    
    double numero = 8.528; // Ingresamos un número para testing

    /* Para el truncamiento utilizamos el casteo a entero signado */
    int truncado = (int) numero;

    /* La parte decimal es el número restando la parte entera correspondiente */
    double parte_decimal = numero - truncado;

    /*  Función techo: 
        Si el número es positivo y no entero, devuelve el entero siguiente. 
        Si no, devuelve la parte entera del original */
    int techo = ((numero > 0) && (parte_decimal != 0)) ? truncado + 1 : truncado;

    /*  Función piso: 
        Si el número es negativo y no entero, devuelve el entero anterior. 
        Si no, devuelve la parte entera del original */
    int piso  = ((numero < 0) && (parte_decimal != 0)) ? truncado - 1 : truncado;

    /*  Función redondeo:
        Si la parte decimal es mayor a 0.5 o está en (-0.5, 0], devuelve el techo. 
        Si no, el piso */
    int redondeo = ((parte_decimal >= 0.5) || (parte_decimal <= 0 && parte_decimal > -0.5)) ? techo : piso;


    /*  Función redondeo a 2 decimales:
        Se implementa el código equivalente al redondeo, pero se multiplica por 100 el número original
        para luego, al final de la secuencia, dividirlo por 100 y obtener los 2 decimales de precisión redondeados.
    */
    double numero_mult = numero * 100;
    int truncado_mult = (int) numero_mult;
    double parte_decimal100 = numero_mult - truncado_mult;
    int techo100 = ((numero_mult > 0) && (parte_decimal100 != 0)) ? truncado_mult + 1 : truncado_mult;
    int piso100 = ((numero_mult < 0) && (parte_decimal100 != 0)) ? truncado_mult - 1 : truncado_mult;
    double redondeo100 = (((parte_decimal100 >= 0.5) || (parte_decimal100 <= 0 && parte_decimal100 > -0.5)) ? techo100 : piso100) / 100.0;
    
    
    printf("Original: \t\t%f\n", numero);
    printf("a) Techo: \t\t%d\n", techo);
    printf("b) Piso: \t\t%d\n", piso);
    printf("c) Redondeo: \t\t%d\n", redondeo);
    printf("d) Truncado: \t\t%d\n", truncado);
    printf("e) Redondeo a 2 cifras: %.2f\n", redondeo100);

    return 0;
}