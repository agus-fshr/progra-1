var files_dup =
[
    [ "conway.c", "conway_8c.html", "conway_8c" ],
    [ "conway.h", "conway_8h.html", "conway_8h" ],
    [ "helper_functions.c", "helper__functions_8c.html", "helper__functions_8c" ],
    [ "helper_functions.h", "helper__functions_8h.html", "helper__functions_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ]
];