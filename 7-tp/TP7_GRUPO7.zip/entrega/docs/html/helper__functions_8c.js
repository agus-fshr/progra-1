var helper__functions_8c =
[
    [ "clear_screen", "helper__functions_8c.html#abc40cd622f423abf44084c8f8595f57f", null ],
    [ "flush_stdin", "helper__functions_8c.html#ad28147e4bdcc806db622550f264e57d5", null ]
];