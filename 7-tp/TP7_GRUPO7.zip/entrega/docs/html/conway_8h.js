var conway_8h =
[
    [ "ALIVE", "conway_8h.html#ad8beef706da0344be19d59438fcdab6d", null ],
    [ "ALIVE_CHAR", "conway_8h.html#af389ca69162561df905b9ed23fa1b439", null ],
    [ "DEAD", "conway_8h.html#a3c8793c7acb4598d2ebcd8288f29ee69", null ],
    [ "DEAD_CHAR", "conway_8h.html#a1e50cf7b88288775430bb0f360db5bf6", null ],
    [ "OUTSIDE_STATE", "conway_8h.html#ae2fe5fdcfc827edaf0ec166503046852", null ],
    [ "SEPARATOR", "conway_8h.html#af68c3a5ad6ffce6c97fff154856a823d", null ],
    [ "WORLD_HEIGHT", "conway_8h.html#a7745e192058dc5174a4cbf59392603d4", null ],
    [ "WORLD_WIDTH", "conway_8h.html#a16d30947295d26898d1b13f10fb9b2ec", null ],
    [ "advance_generation", "conway_8h.html#ae098375d965c6fc2c275a913904adbac", null ],
    [ "initialize_world", "conway_8h.html#a074462a8321d858de6373a66bbb74219", null ],
    [ "print_world", "conway_8h.html#aa0d80137c67f1a8738fb48390dbf1b2c", null ],
    [ "read_generations", "conway_8h.html#a01e6a6d0941ab0d3c7f5888f9c86ca8a", null ]
];