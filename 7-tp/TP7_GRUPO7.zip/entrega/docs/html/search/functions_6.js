var searchData=
[
  ['read_5fgenerations_31',['read_generations',['../conway_8c.html#a01e6a6d0941ab0d3c7f5888f9c86ca8a',1,'read_generations(void):&#160;conway.c'],['../conway_8h.html#a01e6a6d0941ab0d3c7f5888f9c86ca8a',1,'read_generations(void):&#160;conway.c']]]
];
