var searchData=
[
  ['flush_5fstdin_27',['flush_stdin',['../helper__functions_8c.html#ad28147e4bdcc806db622550f264e57d5',1,'flush_stdin(char limit):&#160;helper_functions.c'],['../helper__functions_8h.html#ad28147e4bdcc806db622550f264e57d5',1,'flush_stdin(char limit):&#160;helper_functions.c']]]
];
