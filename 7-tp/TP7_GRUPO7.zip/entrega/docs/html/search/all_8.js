var searchData=
[
  ['print_5fworld_15',['print_world',['../conway_8c.html#aa0d80137c67f1a8738fb48390dbf1b2c',1,'print_world(int world[][WORLD_WIDTH]):&#160;conway.c'],['../conway_8h.html#aa0d80137c67f1a8738fb48390dbf1b2c',1,'print_world(int world[][WORLD_WIDTH]):&#160;conway.c']]]
];
