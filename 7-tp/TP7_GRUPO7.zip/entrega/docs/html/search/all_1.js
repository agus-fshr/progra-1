var searchData=
[
  ['clear_5fscreen_3',['clear_screen',['../helper__functions_8c.html#abc40cd622f423abf44084c8f8595f57f',1,'clear_screen(void):&#160;helper_functions.c'],['../helper__functions_8h.html#abc40cd622f423abf44084c8f8595f57f',1,'clear_screen(void):&#160;helper_functions.c']]],
  ['conway_2ec_4',['conway.c',['../conway_8c.html',1,'']]],
  ['conway_2eh_5',['conway.h',['../conway_8h.html',1,'']]]
];
