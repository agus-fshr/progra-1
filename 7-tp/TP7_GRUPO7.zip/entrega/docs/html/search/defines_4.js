var searchData=
[
  ['world_5fheight_38',['WORLD_HEIGHT',['../conway_8h.html#a7745e192058dc5174a4cbf59392603d4',1,'conway.h']]],
  ['world_5fwidth_39',['WORLD_WIDTH',['../conway_8h.html#a16d30947295d26898d1b13f10fb9b2ec',1,'conway.h']]]
];
