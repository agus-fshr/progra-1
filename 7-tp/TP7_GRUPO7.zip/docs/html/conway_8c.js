var conway_8c =
[
    [ "advance_generation", "conway_8c.html#ae098375d965c6fc2c275a913904adbac", null ],
    [ "initialize_world", "conway_8c.html#a074462a8321d858de6373a66bbb74219", null ],
    [ "print_world", "conway_8c.html#aa0d80137c67f1a8738fb48390dbf1b2c", null ],
    [ "read_generations", "conway_8c.html#a01e6a6d0941ab0d3c7f5888f9c86ca8a", null ]
];