var searchData=
[
  ['alive_32',['ALIVE',['../conway_8h.html#ad8beef706da0344be19d59438fcdab6d',1,'conway.h']]],
  ['alive_5fchar_33',['ALIVE_CHAR',['../conway_8h.html#af389ca69162561df905b9ed23fa1b439',1,'conway.h']]]
];
