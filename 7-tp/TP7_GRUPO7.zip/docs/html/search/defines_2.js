var searchData=
[
  ['outside_5fstate_36',['OUTSIDE_STATE',['../conway_8h.html#ae2fe5fdcfc827edaf0ec166503046852',1,'conway.h']]]
];
