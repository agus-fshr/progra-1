var searchData=
[
  ['advance_5fgeneration_25',['advance_generation',['../conway_8c.html#ae098375d965c6fc2c275a913904adbac',1,'advance_generation(int world_to_advance[][WORLD_WIDTH]):&#160;conway.c'],['../conway_8h.html#ae098375d965c6fc2c275a913904adbac',1,'advance_generation(int world_to_advance[][WORLD_WIDTH]):&#160;conway.c']]]
];
