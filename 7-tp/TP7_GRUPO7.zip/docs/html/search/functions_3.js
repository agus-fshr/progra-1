var searchData=
[
  ['initialize_5fworld_28',['initialize_world',['../conway_8c.html#a074462a8321d858de6373a66bbb74219',1,'initialize_world(int world[][WORLD_WIDTH]):&#160;conway.c'],['../conway_8h.html#a074462a8321d858de6373a66bbb74219',1,'initialize_world(int world[][WORLD_WIDTH]):&#160;conway.c']]]
];
