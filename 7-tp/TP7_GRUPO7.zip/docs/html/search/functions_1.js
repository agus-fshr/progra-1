var searchData=
[
  ['clear_5fscreen_26',['clear_screen',['../helper__functions_8c.html#abc40cd622f423abf44084c8f8595f57f',1,'clear_screen(void):&#160;helper_functions.c'],['../helper__functions_8h.html#abc40cd622f423abf44084c8f8595f57f',1,'clear_screen(void):&#160;helper_functions.c']]]
];
