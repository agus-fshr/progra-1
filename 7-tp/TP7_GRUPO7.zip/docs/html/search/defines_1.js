var searchData=
[
  ['dead_34',['DEAD',['../conway_8h.html#a3c8793c7acb4598d2ebcd8288f29ee69',1,'conway.h']]],
  ['dead_5fchar_35',['DEAD_CHAR',['../conway_8h.html#a1e50cf7b88288775430bb0f360db5bf6',1,'conway.h']]]
];
