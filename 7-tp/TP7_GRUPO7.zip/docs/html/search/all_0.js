var searchData=
[
  ['advance_5fgeneration_0',['advance_generation',['../conway_8c.html#ae098375d965c6fc2c275a913904adbac',1,'advance_generation(int world_to_advance[][WORLD_WIDTH]):&#160;conway.c'],['../conway_8h.html#ae098375d965c6fc2c275a913904adbac',1,'advance_generation(int world_to_advance[][WORLD_WIDTH]):&#160;conway.c']]],
  ['alive_1',['ALIVE',['../conway_8h.html#ad8beef706da0344be19d59438fcdab6d',1,'conway.h']]],
  ['alive_5fchar_2',['ALIVE_CHAR',['../conway_8h.html#af389ca69162561df905b9ed23fa1b439',1,'conway.h']]]
];
