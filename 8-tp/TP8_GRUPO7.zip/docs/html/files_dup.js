var files_dup =
[
    [ "calculator_front.c", "calculator__front_8c.html", "calculator__front_8c" ],
    [ "calculator_front.h", "calculator__front_8h.html", "calculator__front_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "operations.c", "operations_8c.html", "operations_8c" ],
    [ "operations.h", "operations_8h.html", "operations_8h" ]
];