var operations_8h =
[
    [ "PI", "operations_8h.html#a598a3330b3c21701223ee0ca14316eca", null ],
    [ "cos", "operations_8h.html#a7a7d08a90f118f85aae24f1ed5a2b04f", null ],
    [ "division", "operations_8h.html#a5eb1fb5a402a348e8c431bd811653a34", null ],
    [ "factorial", "operations_8h.html#a50dc6b4d257d704c737844d667ef07ca", null ],
    [ "integer_power", "operations_8h.html#ac6c9daa41b5ad2f50e0a87fd0dcfd45f", null ],
    [ "product", "operations_8h.html#aff47c73e752280f9873b8fe428ca55a8", null ],
    [ "sin", "operations_8h.html#a3be967db2043b681fb909184816a2531", null ],
    [ "substraction", "operations_8h.html#a1755e84ac77d088cbdf6625193039b4e", null ],
    [ "sum", "operations_8h.html#aa696b61cebd54eea6ae72f2da02ed1d5", null ]
];