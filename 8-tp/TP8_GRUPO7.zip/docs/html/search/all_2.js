var searchData=
[
  ['div_5fchar_12',['DIV_CHAR',['../main_8c.html#a439522f32e6ae47ed931006e870ae829',1,'main.c']]],
  ['division_13',['division',['../operations_8c.html#a5eb1fb5a402a348e8c431bd811653a34',1,'division(double a, double b):&#160;operations.c'],['../operations_8h.html#a5eb1fb5a402a348e8c431bd811653a34',1,'division(double a, double b):&#160;operations.c']]]
];
