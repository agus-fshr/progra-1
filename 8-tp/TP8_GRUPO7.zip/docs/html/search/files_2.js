var searchData=
[
  ['operations_2ec_51',['operations.c',['../operations_8c.html',1,'']]],
  ['operations_2eh_52',['operations.h',['../operations_8h.html',1,'']]]
];
