var searchData=
[
  ['division_57',['division',['../operations_8c.html#a5eb1fb5a402a348e8c431bd811653a34',1,'division(double a, double b):&#160;operations.c'],['../operations_8h.html#a5eb1fb5a402a348e8c431bd811653a34',1,'division(double a, double b):&#160;operations.c']]]
];
