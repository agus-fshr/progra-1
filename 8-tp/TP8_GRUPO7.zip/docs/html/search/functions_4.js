var searchData=
[
  ['integer_5fpower_62',['integer_power',['../operations_8c.html#a6826b74edd12867f0ddd9e85f0e686f4',1,'integer_power(double base, int exp):&#160;operations.c'],['../operations_8h.html#ac6c9daa41b5ad2f50e0a87fd0dcfd45f',1,'integer_power(double a, int b):&#160;operations.c']]],
  ['integer_5fpower_5fwrapper_63',['integer_power_wrapper',['../main_8c.html#ac785bbcb0a916d38d0eea3cd64b9d174',1,'main.c']]]
];
