var searchData=
[
  ['tan_5fchar_94',['TAN_CHAR',['../main_8c.html#a9df18d35580a7d56e769717cc94bbf11',1,'main.c']]],
  ['taylor_5fterms_95',['TAYLOR_TERMS',['../operations_8c.html#a63353134e11696b5574869e3df0a0f89',1,'operations.c']]]
];
