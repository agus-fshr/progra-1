var searchData=
[
  ['sin_39',['sin',['../operations_8c.html#a3be967db2043b681fb909184816a2531',1,'sin(double a):&#160;operations.c'],['../operations_8h.html#a3be967db2043b681fb909184816a2531',1,'sin(double a):&#160;operations.c']]],
  ['sin_5fchar_40',['SIN_CHAR',['../main_8c.html#a81468e975b731555b779e56ffd2ae4a3',1,'main.c']]],
  ['sin_5fwrapper_41',['sin_wrapper',['../main_8c.html#ae6271594ff3d328bc3eaca1d1dacbd8c',1,'main.c']]],
  ['subs_5fchar_42',['SUBS_CHAR',['../main_8c.html#ad076594cac1704aa54d7dec4ae0cdfa0',1,'main.c']]],
  ['substraction_43',['substraction',['../operations_8c.html#a1755e84ac77d088cbdf6625193039b4e',1,'substraction(double a, double b):&#160;operations.c'],['../operations_8h.html#a1755e84ac77d088cbdf6625193039b4e',1,'substraction(double a, double b):&#160;operations.c']]],
  ['sum_44',['sum',['../operations_8c.html#aa696b61cebd54eea6ae72f2da02ed1d5',1,'sum(double a, double b):&#160;operations.c'],['../operations_8h.html#aa696b61cebd54eea6ae72f2da02ed1d5',1,'sum(double a, double b):&#160;operations.c']]],
  ['sum_5fchar_45',['SUM_CHAR',['../main_8c.html#a92ab67a2bd99b3a1f840258f0e39d6cc',1,'main.c']]]
];
