var searchData=
[
  ['sin_70',['sin',['../operations_8c.html#a3be967db2043b681fb909184816a2531',1,'sin(double a):&#160;operations.c'],['../operations_8h.html#a3be967db2043b681fb909184816a2531',1,'sin(double a):&#160;operations.c']]],
  ['sin_5fwrapper_71',['sin_wrapper',['../main_8c.html#ae6271594ff3d328bc3eaca1d1dacbd8c',1,'main.c']]],
  ['substraction_72',['substraction',['../operations_8c.html#a1755e84ac77d088cbdf6625193039b4e',1,'substraction(double a, double b):&#160;operations.c'],['../operations_8h.html#a1755e84ac77d088cbdf6625193039b4e',1,'substraction(double a, double b):&#160;operations.c']]],
  ['sum_73',['sum',['../operations_8c.html#aa696b61cebd54eea6ae72f2da02ed1d5',1,'sum(double a, double b):&#160;operations.c'],['../operations_8h.html#aa696b61cebd54eea6ae72f2da02ed1d5',1,'sum(double a, double b):&#160;operations.c']]]
];
