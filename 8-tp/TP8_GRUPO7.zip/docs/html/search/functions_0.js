var searchData=
[
  ['add_5foperation_53',['add_operation',['../main_8c.html#a965dd2a0135feedf149965b2fba5f861',1,'main.c']]]
];
