var searchData=
[
  ['actions_74',['actions',['../main_8c.html#a5278fef9d11d8adad50c93146ae9312b',1,'main.c']]]
];
