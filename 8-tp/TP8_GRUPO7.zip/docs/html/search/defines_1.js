var searchData=
[
  ['cos_5fchar_80',['COS_CHAR',['../main_8c.html#ae3f20f389ec84487be54dbd4577eff4f',1,'main.c']]]
];
