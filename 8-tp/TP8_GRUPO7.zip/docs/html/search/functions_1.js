var searchData=
[
  ['clear_5fscreen_54',['clear_screen',['../calculator__front_8c.html#abc40cd622f423abf44084c8f8595f57f',1,'clear_screen(void):&#160;calculator_front.c'],['../calculator__front_8h.html#abc40cd622f423abf44084c8f8595f57f',1,'clear_screen(void):&#160;calculator_front.c']]],
  ['cos_55',['cos',['../operations_8c.html#a7a7d08a90f118f85aae24f1ed5a2b04f',1,'cos(double a):&#160;operations.c'],['../operations_8h.html#a7a7d08a90f118f85aae24f1ed5a2b04f',1,'cos(double a):&#160;operations.c']]],
  ['cos_5fwrapper_56',['cos_wrapper',['../main_8c.html#a56e3f777c97a79830170044350559f69',1,'main.c']]]
];
