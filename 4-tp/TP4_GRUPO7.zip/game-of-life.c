#include <stdio.h>
#include <stdlib.h>

int main(void) {
	system("cat mapa.txt - | ./5");
	return 0;
}
